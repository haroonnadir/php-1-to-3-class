<?php
// Your PHP code goes here
echo "Hello, World!";

$name = "halo i am noor<br>";
echo "My name is $name.<br>";

$name = "noor is my friend";
echo "i love noor because<br> $name<br>";

$name = "noori baba";
echo  "My name is $name";

$name = "haroon";
echo "becuse $name is my frined <br>" ;
?> 
<!-- //This code will output "Hello, World!" when executed -->
