<?php
$x = 10.365;
var_dump($x);
echo "\n";
//    -------------comment-------------------------

define("test",50);
echo test;

$sum = test + 20;
echo $sum;

// assignment  operator (=) is used in PHP to assign a
    $a = 10;
    $b = 3;
    $a =  $a + $b;
    $a += $b;
    $a -=  $b;
    $a *=  $b;
    $a /=  $b;
    $a %=  $b;
    $a **=  $b;
   echo $a;

?>

